package com.goo;
import org.junit.ClassRule;
import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Test;

public class HelloWorldKata_ex1 {
  @Test
  public void ex1() {

           // assertEquals("hello",  ...);
        }
}
