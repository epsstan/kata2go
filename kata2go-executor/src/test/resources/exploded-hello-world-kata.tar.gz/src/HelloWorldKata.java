package com.goo;

import org.junit.ClassRule;
import org.junit.Test;
import static org.junit.Assert.*;

public class HelloWorldKata
{
    @Test
    public void ex1()
    {
       // assertEquals("hello",  ...);
    }

    @Test
    public void ex2()
    {
        // assertEquals("world", ...);
    }
}
